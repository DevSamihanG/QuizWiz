package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class ResultActivity extends AppCompatActivity {


    private TextView scoreTextView;
    private TextView responsesTextView;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        scoreTextView = findViewById(R.id.scoreTextView);
        responsesTextView = findViewById(R.id.responsesTextView);

        Intent intent = getIntent();
        if (intent != null) {
            List<Integer> userResponses = intent.getIntegerArrayListExtra("user_responses");
            List<String> correctAnswers = new ArrayList<>(); // Fill this with correct answers

            // Calculate the score
            int score = calculateScore(userResponses, correctAnswers);

            scoreTextView.setText("Your Score: " + score + "%");
            displayResponses(userResponses, correctAnswers);
        } else {
            Toast.makeText(this, "Error: No data received", Toast.LENGTH_SHORT).show();
        }
    }

    private int calculateScore(List<Integer> userResponses, List<String> correctAnswers) {
        int score = 0;
        for (int i = 0; i < userResponses.size(); i++) {
            if (userResponses.get(i).equals(correctAnswers.get(i))) {
                score++;
            }
        }
        return (int) ((score / (double) userResponses.size()) * 100);
    }



    private void displayResponses(List<Integer> userResponses, List<String> correctAnswers) {
        StringBuilder responseBuilder = new StringBuilder();
        for (int i = 0; i < userResponses.size(); i++) {
            String response = "Q" + (i + 1) + ". Your Response: " + userResponses.get(i) +
                    ". Correct Answer: " + correctAnswers.get(i) + "\n";
            responseBuilder.append(response);
        }
        responsesTextView.setText(responseBuilder.toString());
    }
}



